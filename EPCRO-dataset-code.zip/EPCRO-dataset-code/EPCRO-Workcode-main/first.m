classdef first
    methods(Static)
        function matrix_one = method1(obj,db) 
            %This method gets matrix_one
            %If column 8 of the dataset is 1 (i.e., it is the key protein), then put the value of column 7 of this record into matrix_one
            if db == 1 
                row = size(obj,1)
                for i = 1:row
                    if obj(i, 8) == 1
                        matrix_one(i, 1) = obj(i, 7);
                    else
                        matrix_two(i, 1) = obj(i, 7);
                    end
                end
                matrix_one = unique(matrix_one)
                matrix_two = unique(matrix_two)
            else
                row = size(obj,1)
                for i = 1:row
                    if obj(i, 9) == 1
                        matrix_one(i, 1) = obj(i, 8);
                    else
                        matrix_two(i, 1) = obj(i, 8);
                    end
                end
                matrix_one = unique(matrix_one)
                matrix_two = unique(matrix_two)
            end
        end
        function matrix_two = method2(obj,db)
            %Get matrix_two
            if db == 1 
                row = size(obj,1)
                for i = 1:row
                    if obj(i, 8) == 1
                        matrix_one(i, 1) = obj(i, 7);
                    else
                        matrix_two(i, 1) = obj(i, 7);
                    end
                end
                matrix_one = unique(matrix_one)
                matrix_two = unique(matrix_two)
            else
                row = size(obj,1)
                for i = 1:row
                    if obj(i, 9) == 1
                        matrix_one(i, 1) = obj(i, 8);
                    else
                        matrix_two(i, 1) = obj(i, 8);
                    end
                end
                matrix_one = unique(matrix_one)
                matrix_two = unique(matrix_two)
            end
        end
    end
end
