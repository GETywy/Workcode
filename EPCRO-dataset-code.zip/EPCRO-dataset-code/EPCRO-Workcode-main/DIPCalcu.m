%Total number of proteins in the DIP dataset
totalNo = 5093;
%Number of essential proteins in the DIP dataset
essential_proteins = 1167;
%Number of Top 25% of DIP datasets
TOP25Num = 1274;
%Number of essential proteins predicted by Top 25% of comparison methods
DC=	502;
SC=	467;
IC=	504;
EC=	467;
LAC= 560;
NC=544;
PeC=494;
WDC=566;
EPDRW=630;
RWHN=635;
TEGS= 617;
CFMM= 668;
BSPM= 618;
AFSOEP= 632;
CVIM= 623;
RWEP= 628;
EPPSODC=  601;
EPCRO=	703;
% Respectively, call the method of the "calculate" file to perform the computation and output
disp(calculate.cau('DC',DC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('SC',SC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('IC',IC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('EC',EC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('LAC',LAC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('NC',NC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('PeC',PeC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('WDC',WDC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('EPD-RW',EPDRW,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('RWHN',RWHN,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('TEGS',TEGS,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('CFMM',CFMM,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('BSPM',BSPM,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('AFSO-EP',AFSOEP,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('CVIM',CVIM,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('RWEP',RWEP,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('EPPSO-DC',EPPSODC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('EPCRO',EPCRO,totalNo,essential_proteins,TOP25Num))


