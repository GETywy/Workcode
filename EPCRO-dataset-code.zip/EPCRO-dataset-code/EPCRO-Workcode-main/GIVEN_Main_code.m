% Description:
% The EPCRO algorithm attempts to improve the current solution during each iteration of its execution, 
% and different iteration orders, stopping conditions, or local search strategies may lead to different results.
% Therefore, we select the best value among multiple runs as the result presented in the figures of the EPCRO method in the paper.

load GAVINdata.mat GIVENdataset
par = EPCRO_property();
%Initializing Variables
res = zeros(6000, par.moc_size*2)
mar = first();
data_gavin = mar.handle(GIVENdataset);
%Initialize the matrix, calling the methods named "method1" and "method2" in the first file
matrix_one = mar.method1(data_gavin);
matrix_two = mar.method2(data_gavin);
%Perform molecular calculations, calling the "Molecule" method of the second file
sec = second();
par.loop = 1;
res = sec.Molecule(par,matrix_one,matrix_two,res,data_gavin); 
%Compare the number of essential proteins predicted
thr = third();
resp = thr.method(res,data_gavin);
str1 = sprintf('TOP1 percent result:%d',resp);
%top5%
par.loop = 15;
res = sec.Molecule(par,matrix_one,matrix_two,res,data_gavin); 
thr = third();
resp = thr.method(res,data_gavin);
str2 = sprintf('TOP5 percent result:%d',resp);
%top10%
par.loop = 20;
res = sec.Molecule(par,matrix_one,matrix_two,res,data_gavin); 
thr = third();
resp = thr.method(res,data_gavin);
str3 = sprintf('TOP10 percent result:%d',resp);
%top15%
par.loop = 30;
res = sec.Molecule(par,matrix_one,matrix_two,res,data_gavin); 
thr = third();
resp = thr.method(res,data_gavin);
str4 = sprintf('TOP15 percent result:%d',resp);
%top20%
par.loop = 40;
res = sec.Molecule(par,matrix_one,matrix_two,res,data_gavin); 
thr = third();
resp = thr.method(res,data_gavin);
str5 = sprintf('TOP20 percent result:%d',resp);
%top25%
par.loop = 50;
res = sec.Molecule(par,matrix_one,matrix_two,res,data_gavin); 
thr = third();
resp = thr.method(res,data_gavin);
str6 = sprintf('TOP25 percent result:%d',resp);
cau_str = resp;

disp(str1)
disp(str2)
disp(str3)
disp(str4)
disp(str5)
disp(str6)

disp(Table_calculate.cau('EPCRO',cau_str,par.totalNo_GAVIN,par.essential_proteins_GAVIN,par.GAVIN_TOP25Num))

