%Total number of proteins in the GIVEN dataset
totalNo = 1855;
%Number of essential proteins in the GIVEN dataset
essential_proteins = 464;
%Number of Top 25% of GIVEN datasets
TOP25Num = 714;
%Number of essential proteins predicted by Top 25% of comparison methods
DC	=264;
SC	=240;
IC	=254;
EC	=209;
LAC	=273;
NC	=259;
PeC	=275;
WDC	=286;
EPDRW	=267;
RWHN	=269;
TEGS	=253;
CFMM	=332;
BSPM	=313;
AFSOEP	=326;
CVIM	=322;
RWEP	=251;
EPPSODC	=320;
EPCRO	=348;
%respectively, call the method of the "calculate" file to perform the computation and output
disp(calculate.cau('DC',DC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('SC',SC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('IC',IC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('EC',EC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('LAC',LAC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('NC',NC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('PeC',PeC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('WDC',WDC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('EPD-RW',EPDRW,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('RWHN',RWHN,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('TEGS',TEGS,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('CFMM',CFMM,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('BSPM',BSPM,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('AFSO-EP',AFSOEP,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('CVIM',CVIM,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('RWEP',RWEP,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('EPPSO-DC',EPPSODC,totalNo,essential_proteins,TOP25Num))
disp(calculate.cau('EPCRO',EPCRO,totalNo,essential_proteins,TOP25Num))


