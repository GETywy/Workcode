
classdef CroCodePar < handle
    properties
        PE;
        KE;
        moc_num = 10;
        moc_size = 10;
        cross_rate = 0.5;
        buffer = 0.0;
        loop = 4;
        iter = 20;
    end
end
