classdef Naive_Bayes_Model
    methods(Static)
        function posterior_prob_1 = bayer(data,labels,new_data)
            % prior probability
            prior_prob_0 = sum(labels == 0) / length(labels);
            prior_prob_1 = sum(labels == 1) / length(labels);

            % The conditional probability
            mean_0 = mean(data(labels == 0, :));
            std_0 = std(data(labels == 0, :));
            mean_1 = mean(data(labels == 1, :));
            std_1 = std(data(labels == 1, :));

            % Naive_bayes_model
            new_data_point = new_data;

            % The posterior probability
            posterior_prob_0 = prior_prob_0 * normpdf(new_data_point, mean_0, std_0);
            posterior_prob_1 = prior_prob_1 * normpdf(new_data_point, mean_1, std_1);

            % Determine the classification result
            if posterior_prob_0 > posterior_prob_1
                predicted_class = 0;
            else
                predicted_class = 1;
            end
        end
    end
end

