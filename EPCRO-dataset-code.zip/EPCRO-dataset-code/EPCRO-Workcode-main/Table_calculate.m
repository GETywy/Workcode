%calculate DIP DB SN.
classdef Table_calculate

methods(Static)
    %Calculate the value of SN��SP��PPV��NPV��F-measure��ACC.
    function str = cau(method,TP,totalNo,numOfKeyPrs,TOP25Num)
    FN = numOfKeyPrs - TP;
    FP = TOP25Num - TP;
    TN = totalNo - numOfKeyPrs - FP;

    SN = TP / numOfKeyPrs;  
    SP = TN / (TN + FP);  
    PPV = TP / (TP + FP);
    NPV = TN /(TN + FN);
    Fmeasure = (2 * SN * PPV) / (SN + PPV);
    ACC = (TP + TN) / (TP + TN + FP + FN);
    str = sprintf('%s method SN:%g SP:%g PPV:%g NPV:%g F-measure:%g ACC:%g',method,round(SN,4),round(SP,4),round(PPV,4),round(NPV,4),round(Fmeasure,4),round(ACC,4)); 
    end
end
end






